package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button;
    TextView email,password;
    Button login,signup;
    String email1,password1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        password=(TextView)findViewById(R.id.password);
        email=(TextView)findViewById(R.id.email);
        login=(Button)findViewById(R.id.login);
        signup=(Button)findViewById(R.id.signup);
        button=(Button)findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scroll();
            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email1 = email.getText().toString();
                password1 = password.getText().toString();
                if (email1.equals("ADMIN")) {
                    if(password1.equals("ADMIN")) {
                        Toast.makeText(MainActivity.this, "Correct EMAIL AND PASSWORD", Toast.LENGTH_SHORT).show();
                    }
                    if(!password1.equals("ADMIN")){
                        Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();
                    }
                }
                if (password1.equals("ADMIN")){
                    if (!email1.equals("ADMIN")){
                        Toast.makeText(MainActivity.this, "Incorrect EMAIL", Toast.LENGTH_SHORT).show();
                    }
                }
                if (!password1.equals("ADMIN")){
                    if (!email1.equals("ADMIN")){
                        Toast.makeText(MainActivity.this, "Incorrect EMAIL And PASSWORD", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "CONNECT THROUGH FACEBOOK", Toast.LENGTH_LONG).show();
            }
        });

        }
    public void scroll(){
        Intent intent = new Intent(this,ScrollingActivity.class);
        startActivity(intent);
    }

}