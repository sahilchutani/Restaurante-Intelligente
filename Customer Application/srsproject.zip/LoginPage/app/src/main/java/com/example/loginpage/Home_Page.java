package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;

public class Home_Page extends AppCompatActivity {

    ImageView backbtn;
    Button btn,btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home__page);
        // for going back
        backbtn = findViewById(R.id.back_pressed);
        btn = findViewById(R.id.btn);
        btn1 = findViewById(R.id.btn1);

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openn();

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                threesixty();
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                threesixty1();
            }
        });

    }
    public void threesixty(){
        Intent intent = new Intent(this,seat.class);
        startActivity(intent);
    }
    public void threesixty1(){
        Intent intent = new Intent(this,seat1.class);
        startActivity(intent);
    }
    public void openn(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}