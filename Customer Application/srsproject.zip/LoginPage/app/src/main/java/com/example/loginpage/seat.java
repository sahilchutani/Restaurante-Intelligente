package com.example.loginpage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;

import co.gofynd.gravityview.GravityView;

public class seat extends AppCompatActivity {
    GravityView gravityView;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat);
        ImageView img = findViewById(R.id.img);
        gravityView = GravityView.getInstance(this);
        boolean is_supported = gravityView.deviceSupported();
        if(is_supported) {
            gravityView
                    .setImage(img,R.drawable.pan)
                    .center();
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        gravityView.registerListener();
    }
    @Override
    protected void onStop() {
        super.onStop();
        gravityView.unRegisterListener();
    }

}